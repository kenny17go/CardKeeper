CardKeeper PaddleOCR Debug Package

working-v7/ = PaddleOCR v7 / 720px version that worked on the same iPhone Safari.
integration/ = CardKeeper integration version currently failing with "PaddleOCR module unavailable"; earlier attempts also showed "Load failed".

Please compare Vite bundling, Worker/model/WASM asset URLs, GitHub Pages subfolder paths, ES module loading, Service Worker caching, and when window.CardPaddleOCR is created.
Goal: minimal fix; do not rewrite CardKeeper.
